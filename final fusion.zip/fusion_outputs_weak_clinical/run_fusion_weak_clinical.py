"""
NeuroInsight - Fusion experiment with a WEAKER clinical baseline (Age + Sex only).

Purpose: the full clinical model (using NP3 motor-exam items) already gets 100%
on the test set, so there's no room for fusion to show improvement. This script
retrains a clinical model using ONLY Age and Sex - a much harder, more realistic
signal - to get a fairer test of whether MRI actually adds value in fusion.

Folder layout expected (same as run_fusion.py):
    <this_folder>/
        run_fusion_weak_clinical.py
        NeuroInsight-likhi (1)/NeuroInsight-likhi/data/clinical/clinical_train.csv
        NeuroInsight-likhi (1)/NeuroInsight-likhi/data/clinical/clinical_test.csv
        NeuroInsight-mri-model/NeuroInsight-mri-model/models/mri/multiview_resnet50/results/subject_predictions.csv
        NeuroInsight-mri-model/NeuroInsight-mri-model/models/mri/multiview_resnet50/results/train_subject_predictions.csv

Edit the paths below if your folder names differ.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve
import matplotlib.pyplot as plt

RANDOM_STATE = 42
BASE = Path(__file__).parent

CLINICAL_TRAIN_RAW = BASE / "NeuroInsight-likhi (1)/NeuroInsight-likhi/data/clinical/clinical_train.csv"
CLINICAL_TEST_RAW = BASE / "NeuroInsight-likhi (1)/NeuroInsight-likhi/data/clinical/clinical_test.csv"
MRI_TEST_PREDICTIONS = BASE / "NeuroInsight-mri-model/NeuroInsight-mri-model/models/mri/multiview_resnet50/results/subject_predictions.csv"
MRI_TRAIN_PREDICTIONS = BASE / "NeuroInsight-mri-model/NeuroInsight-mri-model/models/mri/multiview_resnet50/results/train_subject_predictions.csv"

OUT_DIR = BASE / "fusion_outputs_weak_clinical"
OUT_DIR.mkdir(exist_ok=True)


def compute_metrics(y_true, prob, thresh=0.5):
    pred = (prob >= thresh).astype(int)
    return {
        "Accuracy": accuracy_score(y_true, pred),
        "Precision": precision_score(y_true, pred, zero_division=0),
        "Recall": recall_score(y_true, pred),
        "F1": f1_score(y_true, pred, zero_division=0),
        "ROC_AUC": roc_auc_score(y_true, prob),
    }


def build_clinical_pipeline():
    preproc = ColumnTransformer(transformers=[
        ("age", Pipeline([("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler())]), ["Age"]),
        ("sex", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                           ("encoder", OneHotEncoder(handle_unknown="ignore"))]), ["Sex"]),
    ])
    return Pipeline([
        ("preprocessing", preproc),
        ("model", LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)),
    ])


def main():
    clin_train_raw = pd.read_csv(CLINICAL_TRAIN_RAW)
    clin_test_raw = pd.read_csv(CLINICAL_TEST_RAW)

    X_train_clin = clin_train_raw[["Age", "Sex"]]
    y_train = clin_train_raw["Label"].values
    X_test_clin = clin_test_raw[["Age", "Sex"]]
    y_test = clin_test_raw["Label"].values

    # Out-of-fold predictions on train (avoids leakage: each train subject's
    # clinical probability comes from a model that never saw that subject)
    pipe = build_clinical_pipeline()
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    oof_clin_prob = cross_val_predict(pipe, X_train_clin, y_train, cv=skf, method="predict_proba")[:, 1]

    # Refit on all training data for the final test-set prediction
    pipe.fit(X_train_clin, y_train)
    test_clin_prob = pipe.predict_proba(X_test_clin)[:, 1]

    print(f"Age+Sex-only clinical model - test set: "
          f"{compute_metrics(y_test, test_clin_prob)}")

    # ---- Bring in MRI predictions, align by Subject ----
    mri_test = pd.read_csv(MRI_TEST_PREDICTIONS)
    mri_train = pd.read_csv(MRI_TRAIN_PREDICTIONS)

    train_df = clin_train_raw[["Subject", "Label"]].copy()
    train_df["Clinical_PD_Probability"] = oof_clin_prob
    train_df = train_df.merge(mri_train[["Subject", "MRI_PD_Probability"]], on="Subject", how="inner")

    test_df = clin_test_raw[["Subject", "Label"]].copy()
    test_df["Clinical_PD_Probability"] = test_clin_prob
    test_df = test_df.merge(mri_test[["Subject", "MRI_PD_Probability"]], on="Subject", how="inner")

    assert train_df["Subject"].duplicated().sum() == 0
    assert test_df["Subject"].duplicated().sum() == 0
    assert len(set(train_df["Subject"]) & set(test_df["Subject"])) == 0
    print(f"Aligned: {len(train_df)} train, {len(test_df)} test subjects")

    X_train = train_df[["MRI_PD_Probability", "Clinical_PD_Probability"]].values
    y_train_aligned = train_df["Label"].values
    X_test = test_df[["MRI_PD_Probability", "Clinical_PD_Probability"]].values
    y_test_aligned = test_df["Label"].values

    results = {
        "MRI only": compute_metrics(y_test_aligned, test_df["MRI_PD_Probability"].values),
        "Clinical only (Age+Sex)": compute_metrics(y_test_aligned, test_df["Clinical_PD_Probability"].values),
    }

    avg_prob = test_df[["MRI_PD_Probability", "Clinical_PD_Probability"]].mean(axis=1).values
    results["Fusion (average baseline)"] = compute_metrics(y_test_aligned, avg_prob)

    mlp = MLPClassifier(hidden_layer_sizes=(16, 8), activation="relu", solver="adam",
                         alpha=1e-3, max_iter=3000, random_state=RANDOM_STATE)
    mlp.fit(X_train, y_train_aligned)
    mlp_prob = mlp.predict_proba(X_test)[:, 1]
    results["Fusion (trained MLP)"] = compute_metrics(y_test_aligned, mlp_prob)

    comp_table = pd.DataFrame(results).T[["Accuracy", "Precision", "Recall", "F1", "ROC_AUC"]].round(4)
    print("\n=== Comparison on held-out test set (Age+Sex-only clinical baseline, n=%d) ===" % len(test_df))
    print(comp_table.to_string())
    comp_table.to_csv(OUT_DIR / "model_comparison_weak_clinical.csv")

    # Save fusion_predictions.csv for ALL subjects (train + test), in the
    # exact column format requested: Subject, Label, MRI_PD_Probability,
    # Clinical_PD_Probability, Fusion_PD_Probability, Fusion_Prediction
    train_out = train_df.copy()
    train_out["Split"] = "train"
    train_out["Fusion_PD_Probability"] = mlp.predict_proba(X_train)[:, 1]

    test_out = test_df.copy()
    test_out["Split"] = "test"
    test_out["Fusion_PD_Probability"] = mlp_prob

    all_out = pd.concat([train_out, test_out], ignore_index=True)
    all_out["Fusion_Prediction"] = (all_out["Fusion_PD_Probability"] >= 0.5).astype(int)
    all_out = all_out[["Subject", "Label", "Split", "MRI_PD_Probability",
                        "Clinical_PD_Probability", "Fusion_PD_Probability", "Fusion_Prediction"]]
    all_out = all_out.sort_values("Subject").reset_index(drop=True)
    all_out.to_csv(OUT_DIR / "fusion_predictions.csv", index=False)
    print(f"\nSaved fusion_predictions.csv with {len(all_out)} rows (train+test)")

    fig, ax = plt.subplots(figsize=(6.5, 6))
    for label, prob in [
        ("MRI only", test_df["MRI_PD_Probability"].values),
        ("Clinical only (Age+Sex)", test_df["Clinical_PD_Probability"].values),
        ("Fusion (MLP)", mlp_prob),
    ]:
        fpr, tpr, _ = roc_curve(y_test_aligned, prob)
        auc = roc_auc_score(y_test_aligned, prob)
        ax.plot(fpr, tpr, label=f"{label} (AUC={auc:.3f})", linewidth=2)
    ax.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Chance")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curves - Age+Sex-only Clinical Baseline")
    ax.legend(loc="lower right")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(OUT_DIR / "roc_curves_weak_clinical.png", dpi=150)

    print(f"\nSaved outputs to: {OUT_DIR}")


if __name__ == "__main__":
    main()
