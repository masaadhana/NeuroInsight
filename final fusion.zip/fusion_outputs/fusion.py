"""
NeuroInsight - Late Fusion (MRI + Clinical) for PD classification.

Expected folder layout (place this script one level above both project folders,
e.g. run it from a parent folder containing both repos exactly as downloaded):

    <this_folder>/
    
        run_fusion.py
        NeuroInsight-likhi/
            results/clinical/clinical_predictions.csv
        NeuroInsight-mri-model/
            models/mri/multiview_resnet50/results/subject_predictions.csv
            models/mri/multiview_resnet50/results/train_subject_predictions.csv

If your folders are named differently, just edit the three paths below.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve

RANDOM_STATE = 42
BASE = Path(__file__).parent

CLINICAL_PREDICTIONS = BASE / "NeuroInsight-likhi (1)/NeuroInsight-likhi/results/clinical/clinical_predictions.csv"
MRI_TEST_PREDICTIONS = BASE / "NeuroInsight-mri-model/NeuroInsight-mri-model/models/mri/multiview_resnet50/results/subject_predictions.csv"
MRI_TRAIN_PREDICTIONS = BASE / "NeuroInsight-mri-model/NeuroInsight-mri-model/models/mri/multiview_resnet50/results/train_subject_predictions.csv"

OUT_DIR = BASE / "fusion_outputs"
OUT_DIR.mkdir(exist_ok=True)


def compute_metrics(y_true, prob, thresh=0.5):
    pred = (prob >= thresh).astype(int)
    return {
        "Accuracy": accuracy_score(y_true, pred),
        "Precision": precision_score(y_true, pred, zero_division=0),
        "Recall": recall_score(y_true, pred),
        "F1": f1_score(y_true, pred, zero_division=0),
        "ROC_AUC": roc_auc_score(y_true, prob),
    }


def main():
    clin = pd.read_csv(CLINICAL_PREDICTIONS)
    mri_test = pd.read_csv(MRI_TEST_PREDICTIONS)
    mri_train = pd.read_csv(MRI_TRAIN_PREDICTIONS)
    mri_all = pd.concat([mri_train.assign(Split="train"), mri_test.assign(Split="test")], ignore_index=True)

    merged = pd.merge(
        clin[["Subject", "Label", "Split", "PD_Probability"]].rename(columns={"PD_Probability": "Clinical_PD_Probability"}),
        mri_all[["Subject", "MRI_PD_Probability"]],
        on="Subject", how="inner",
    )

    # Integrity checks
    assert merged["Subject"].duplicated().sum() == 0, "Duplicate subjects found"
    assert len(merged) == len(clin) == len(mri_all), "Subject count mismatch between modalities"
    assert len(set(mri_all["Subject"]) - set(clin["Subject"])) == 0, "Subjects missing from clinical data"
    assert len(set(clin["Subject"]) - set(mri_all["Subject"])) == 0, "Subjects missing from MRI data"

    train_df = merged[merged["Split"] == "train"].reset_index(drop=True)
    test_df = merged[merged["Split"] == "test"].reset_index(drop=True)
    print(f"Aligned {len(merged)} subjects -> {len(train_df)} train / {len(test_df)} test. "
          f"Train/test overlap: {len(set(train_df['Subject']) & set(test_df['Subject']))}")

    X_train = train_df[["MRI_PD_Probability", "Clinical_PD_Probability"]].values
    y_train = train_df["Label"].values
    X_test = test_df[["MRI_PD_Probability", "Clinical_PD_Probability"]].values
    y_test = test_df["Label"].values

    results = {
        "MRI only": compute_metrics(y_test, test_df["MRI_PD_Probability"].values),
        "Clinical only": compute_metrics(y_test, test_df["Clinical_PD_Probability"].values),
    }

    avg_prob = test_df[["MRI_PD_Probability", "Clinical_PD_Probability"]].mean(axis=1).values
    results["Fusion (average baseline)"] = compute_metrics(y_test, avg_prob)

    mlp = MLPClassifier(
        hidden_layer_sizes=(16, 8), activation="relu", solver="adam",
        alpha=1e-3, max_iter=3000, random_state=RANDOM_STATE,
    )
    mlp.fit(X_train, y_train)
    mlp_prob = mlp.predict_proba(X_test)[:, 1]
    results["Fusion (trained MLP)"] = compute_metrics(y_test, mlp_prob)

    comp_table = pd.DataFrame(results).T[["Accuracy", "Precision", "Recall", "F1", "ROC_AUC"]].round(4)
    print("\n=== Comparison on held-out test set (n=%d) ===" % len(test_df))
    print(comp_table.to_string())
    comp_table.to_csv(OUT_DIR / "model_comparison.csv")

    # Save fusion predictions for all subjects
    X_all = merged[["MRI_PD_Probability", "Clinical_PD_Probability"]].values
    merged_out = merged.copy()
    merged_out["Fusion_PD_Probability"] = mlp.predict_proba(X_all)[:, 1]
    merged_out["Fusion_Prediction"] = (merged_out["Fusion_PD_Probability"] >= 0.5).astype(int)
    merged_out.sort_values("Subject").to_csv(OUT_DIR / "fusion_predictions.csv", index=False)
    print(f"\nSaved: {OUT_DIR / 'fusion_predictions.csv'}")
    print(f"Saved: {OUT_DIR / 'model_comparison.csv'}")

    # ROC plot
    fig, ax = plt.subplots(figsize=(6.5, 6))
    for label, prob in [
        ("MRI only", test_df["MRI_PD_Probability"].values),
        ("Clinical only", test_df["Clinical_PD_Probability"].values),
        ("Fusion (MLP)", mlp_prob),
    ]:
        fpr, tpr, _ = roc_curve(y_test, prob)
        auc = roc_auc_score(y_test, prob)
        ax.plot(fpr, tpr, label=f"{label} (AUC={auc:.3f})", linewidth=2)
    ax.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Chance")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curves - Test Set")
    ax.legend(loc="lower right")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(OUT_DIR / "roc_curves_comparison.png", dpi=150)
    print(f"Saved: {OUT_DIR / 'roc_curves_comparison.png'}")


if __name__ == "__main__":
    main()
