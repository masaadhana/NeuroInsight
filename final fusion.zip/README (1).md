# NeuroInsight — Fusion Stage

Late-fusion of the **MRI** and **Clinical** models into a single Parkinson's Disease (PD) prediction.

## What this does

Combines subject-level probabilities from two independently trained modality models:

- **MRI model** (Multi-View ResNet50) → `MRI_PD_Probability`
- **Clinical model** (motor-exam features) → `Clinical_PD_Probability`

into a single fused prediction, and compares MRI-only, Clinical-only, and Fusion performance on a held-out test set.

## Files

| File | Purpose |
|---|---|
| `run_fusion.py` | Main fusion pipeline using the full clinical model (all NP3 motor-exam features). Produces `fusion_outputs/`. |
| `run_fusion_weak_clinical.py` | Same pipeline, but retrains the clinical side using **only Age + Sex** — see "Why two versions" below. Produces `fusion_outputs_weak_clinical/`. |
| `requirements.txt` | Python dependencies (pandas, numpy, scikit-learn, matplotlib, joblib). |

## How to run

```
python -m venv venv
.\venv\Scripts\activate        # Windows
pip install -r requirements.txt
python run_fusion.py
python run_fusion_weak_clinical.py
```

Each script expects the MRI and clinical project folders to sit alongside it (see the path constants at the top of each script — adjust if your folder names differ). Each writes its own output folder containing:

- `fusion_predictions.csv` — Subject, Label, Split, MRI_PD_Probability, Clinical_PD_Probability, Fusion_PD_Probability, Fusion_Prediction (all 277 subjects)
- `model_comparison.csv` — Accuracy / Precision / Recall / F1 / ROC-AUC for MRI-only, Clinical-only, Fusion (average), Fusion (trained MLP)
- `roc_curves_comparison.png` — ROC curves for all three approaches

## Method

1. **Alignment** — MRI and clinical predictions are merged on `Subject`. Verified: no duplicate subjects, no missing subjects on either side, labels agree between modalities, no train/test overlap.
2. **Baseline** — simple average of the two probabilities.
3. **Trained fusion** — small MLP (2 inputs → Dense(16, ReLU) → Dense(8, ReLU) → Dense(1, sigmoid)), fit on train-split probabilities, evaluated once on the untouched test split.

## Why two versions

The full clinical model (using all `NP3*` motor-exam items) gets **100% accuracy on the test set on its own**. Those items are the individual scores of the MDS-UPDRS Part III motor exam — the same exam clinicians use to characterize parkinsonism — so the clinical model is close to re-deriving the label rather than finding a subtle biomarker. That leaves fusion no room to improve anything: `run_fusion.py`'s Fusion result is just the clinical model's ceiling performance carried through.

`run_fusion_weak_clinical.py` retrains the clinical side using only `Age` + `Sex` (a genuinely weak, non-diagnostic signal) as a fairer test of whether MRI adds real value. It also uses 5-fold out-of-fold predictions for the clinical model's train-split probabilities, avoiding the leakage risk of reusing in-sample predictions to train the fusion layer.

## Results

**Full clinical model (`run_fusion.py`), test set n=56:**

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| MRI only | 0.554 | 0.548 | 0.607 | 0.576 | 0.630 |
| Clinical only | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |
| Fusion (average) | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |
| Fusion (trained MLP) | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |

**Age+Sex-only clinical model (`run_fusion_weak_clinical.py`), test set n=56:**

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|
| MRI only | 0.554 | 0.548 | 0.607 | 0.576 | 0.630 |
| Clinical only (Age+Sex) | 0.464 | 0.458 | 0.393 | 0.423 | 0.489 |
| Fusion (average) | 0.625 | 0.621 | 0.643 | 0.632 | 0.615 |
| Fusion (trained MLP) | 0.554 | 0.531 | 0.929 | 0.675 | 0.635 |

## Takeaway

- On the full clinical feature set, fusion can't be shown to help — the clinical model already saturates the test metrics.
- On a deliberately weaker clinical baseline (Age+Sex only), fusion modestly outperforms both individual modalities (AUC 0.63 vs. 0.63 for MRI and 0.49 for clinical alone, with a large recall gain for the trained MLP). This is a more honest test of MRI's contribution and the more defensible "fusion helps" result to report.

## Next steps

- XAI stage: Grad-CAM for MRI region attribution, a feature-attribution method (e.g. SHAP) for clinical features, and a modality-contribution comparison — as originally scoped.
